package com.meera.ai.ui

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/*
 * Glassmorphism kit (v2.4).
 * "Glass" here = frosted translucent panel: a dark smoky base + a white-to-clear gradient + a bright 1 dp rim that fades
 * around the edge + a soft highlight on the top edge. There is NO real background blur (Compose cannot blur what is
 * behind a view on every Android version), so the effect is built from translucency, which looks right over the videos.
 */

private val GlassRimDark = listOf(Color.White.copy(alpha = 0.70f), Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.30f))

/** Frosted-glass surface. [strength] 0.5 (very light) .. 1.5 (heavier). */
@Composable
fun Modifier.glass(shape: Shape = RoundedCornerShape(24.dp), strength: Float = 1f): Modifier {
    val light = MaterialTheme.colorScheme.background.luminance() > 0.5f
    val smoke = if (light) Color(0xFFFFFFFF).copy(alpha = 0.35f * strength) else Color(0xFF070C26).copy(alpha = 0.38f * strength)
    val tintA = if (light) 0.55f else 0.20f
    val tintB = if (light) 0.20f else 0.05f
    val rim = if (light) listOf(Color.White.copy(alpha = 0.9f), Color(0xFF7C6FD6).copy(alpha = 0.25f), Color.White.copy(alpha = 0.6f)) else GlassRimDark
    return this
        .clip(shape)
        .background(smoke)
        .background(Brush.linearGradient(listOf(Color.White.copy(alpha = tintA * strength), Color.White.copy(alpha = tintB * strength))))
        .drawBehind {
            // soft light reflection along the top edge
            drawRect(
                Brush.verticalGradient(listOf(Color.White.copy(alpha = if (light) 0.5f else 0.16f), Color.Transparent), endY = size.height * 0.35f),
            )
        }
        .border(1.dp, Brush.linearGradient(rim), shape)
}

/** Glass panel for content (replaces the old GlowCard look). */
@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    shape: Shape = RoundedCornerShape(22.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    val m = modifier.glass(shape).let { if (onClick != null) it.clickable { onClick() } else it }
    Column(m.padding(14.dp), content = content)
}

/** Round or pill glass button with a soft press "squish". Content is centred. */
@Composable
fun GlassButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = CircleShape,
    tint: Color? = null,          // optional colour wash (e.g. red for End call)
    strength: Float = 1f,
    content: @Composable BoxScope.() -> Unit
) {
    var pressed by remember { mutableStateOf(false) }
    val sc by animateFloatAsState(if (pressed) 0.92f else 1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "press")
    Box(
        modifier
            .scale(sc)
            .glass(shape, strength)
            .let { b -> if (tint != null) b.background(Brush.linearGradient(listOf(tint.copy(alpha = 0.55f), tint.copy(alpha = 0.18f)))) else b }
            .pointerInput(Unit) {
                detectTapGestures(onPress = { pressed = true; tryAwaitRelease(); pressed = false }, onTap = { onClick() })
            },
        contentAlignment = Alignment.Center,
        content = content
    )
}

/** Small glass label under an icon button ("Menu", "Chat" ...). */
@Composable
fun GlassLabel(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier = modifier, color = Color.White.copy(alpha = 0.9f), fontSize = 11.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.sp)
}

/** Small status pill (glass). */
@Composable
fun GlassPill(text: String, dot: Color? = null, modifier: Modifier = Modifier) {
    androidx.compose.foundation.layout.Row(
        modifier.glass(RoundedCornerShape(50), 0.9f).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(7.dp)
    ) {
        if (dot != null) Box(Modifier.size(7.dp).clip(CircleShape).background(dot))
        Text(text, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

/**
 * Background for the non-video screens: deep blue-violet gradient with two soft colour glows,
 * so glass panels have something to "refract". Drawn once, no animation (cheap).
 */
fun Modifier.glassBackground(): Modifier = this.drawBehind {
    drawRect(Brush.verticalGradient(listOf(Color(0xFF050818), Color(0xFF0A1033), Color(0xFF120B30))))
    drawCircle(
        Brush.radialGradient(listOf(Cyan.copy(alpha = 0.30f), Color.Transparent), center = Offset(size.width * 0.15f, size.height * 0.12f), radius = size.width * 0.9f),
        radius = size.width * 0.9f, center = Offset(size.width * 0.15f, size.height * 0.12f)
    )
    drawCircle(
        Brush.radialGradient(listOf(Purple.copy(alpha = 0.32f), Color.Transparent), center = Offset(size.width * 0.9f, size.height * 0.85f), radius = size.width * 1.0f),
        radius = size.width * 1.0f, center = Offset(size.width * 0.9f, size.height * 0.85f)
    )
}

/** Light-theme version of the same background. */
fun Modifier.glassBackgroundLight(): Modifier = this.drawBehind {
    drawRect(Brush.verticalGradient(listOf(Color(0xFFEAF4FF), Color(0xFFF1EBFF), Color(0xFFFBEFFF))))
    drawCircle(
        Brush.radialGradient(listOf(Cyan.copy(alpha = 0.25f), Color.Transparent), center = Offset(size.width * 0.1f, size.height * 0.1f), radius = size.width * 0.9f),
        radius = size.width * 0.9f, center = Offset(size.width * 0.1f, size.height * 0.1f)
    )
}

/** Picks the dark or light glass background from the current theme. */
@Composable
fun Modifier.themedGlassBackground(): Modifier =
    if (MaterialTheme.colorScheme.background.luminance() > 0.5f) this.glassBackgroundLight() else this.glassBackground()

/** Thin decorative glow line (used as a divider under titles). */
@Composable
fun GlassDivider(modifier: Modifier = Modifier, width: Dp = 1.dp) {
    Canvas(modifier.padding(vertical = 4.dp).size(width = 100.dp, height = width)) {
        drawRect(Brush.horizontalGradient(listOf(Color.Transparent, Cyan.copy(alpha = 0.8f), Color.Transparent)))
    }
}
