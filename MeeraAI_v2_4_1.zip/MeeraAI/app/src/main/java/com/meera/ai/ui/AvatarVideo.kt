package com.meera.ai.ui

import android.content.Context
import android.net.Uri
import android.view.TextureView
import android.widget.FrameLayout
import androidx.annotation.DrawableRes
import androidx.annotation.RawRes
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.max

/**
 * A request to show one video clip. The same clip with a NEW [nonce] means "start it again" (used for the loop seam),
 * so the player cross-fades from the end of the old play into the start of the new one - no visible cut.
 */
data class ClipReq(@RawRes val res: Int, val nonce: Int = 0)

/**
 * Full-screen video with a built-in "mix" effect.
 *
 * Two ExoPlayers draw on two stacked TextureViews. When [req] changes, the next clip is prepared on the hidden player,
 * and as soon as its first frame is on screen it is faded in (alpha 0 -> 1) on top of the old one. The old one is paused afterwards.
 * Result: expression changes and loop restarts look like one continuous take, not like a different video starting.
 *
 * The video is scaled to COVER the whole area (9:16 source -> full screen, sides/top cropped on other aspect ratios),
 * never stretched. Quality: the MP4 files are used exactly as supplied (no re-encoding).
 *
 * @param poster still image shown under the video until the first frame is ready (no black flash)
 * @param fadeMs length of the mix effect when the clip changes (the first clip fades in over [introMs] from the poster/black)
 */
@Composable
fun VideoCrossfade(
    req: ClipReq,
    @DrawableRes poster: Int,
    modifier: Modifier = Modifier,
    fadeMs: Int = 450,
    introMs: Int = 700
) {
    val ctx = LocalContext.current
    val stage = remember { VideoStage(ctx) }
    val lifecycle = LocalLifecycleOwner.current.lifecycle

    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_STOP -> stage.pause()
                Lifecycle.Event.ON_START -> stage.resume()
                else -> {}
            }
        }
        lifecycle.addObserver(obs)
        onDispose { lifecycle.removeObserver(obs); stage.release() }
    }

    LaunchedEffect(req) { stage.show(req, if (stage.hasShown) fadeMs else introMs) }

    Box(modifier.fillMaxSize().clipToBounds()) {
        Image(painterResource(poster), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        AndroidView(
            factory = { stage.root },
            modifier = Modifier
                .fillMaxSize()
                .layout { m, c ->
                    // "cover" scaling for a 720x1280 (9:16) source: scale so the video fills the area, centre it, crop the rest
                    val w = c.maxWidth
                    val h = c.maxHeight
                    val k = max(w / 720f, h / 1280f)
                    val vw = (720 * k).toInt()
                    val vh = (1280 * k).toInt()
                    val p = m.measure(androidx.compose.ui.unit.Constraints.fixed(vw, vh))
                    layout(w, h) { p.place((w - vw) / 2, (h - vh) / 2) }
                }
        )
    }
}

/** Two players + two texture views and the cross-fade between them. Main-thread only. */
private class VideoStage(private val ctx: Context) {
    private class Slot(val view: TextureView, val player: ExoPlayer)

    val root = FrameLayout(ctx)
    private val slots: Array<Slot>
    private var front = -1       // slot currently on screen (-1 = nothing yet)
    private var released = false
    private var paused = false
    var hasShown = false; private set
    private val fade = Animatable(0f)

    init {
        slots = Array(2) {
            val tv = TextureView(ctx).apply { alpha = 0.01f; isOpaque = false }
            val p = ExoPlayer.Builder(ctx).build().apply {
                volume = 0f                       // the avatar clips are silent on purpose; Meera's voice comes from the call itself
                // v2.4.1: do not even OPEN an audio decoder / AudioTrack. A silent-but-open media AudioTrack next to the call
                // microphone (VOICE_COMMUNICATION) makes some phones deliver only zeros from the mic.
                trackSelectionParameters = trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true)
                    .build()
                repeatMode = Player.REPEAT_MODE_ONE // safety net: never freeze on the last frame if the next request is late
                playWhenReady = true
                setVideoTextureView(tv)
            }
            root.addView(tv, FrameLayout.LayoutParams(-1, -1))
            Slot(tv, p)
        }
    }

    private fun uri(@RawRes res: Int): Uri = Uri.parse("android.resource://${ctx.packageName}/$res")

    suspend fun show(req: ClipReq, ms: Int) {
        if (released) return
        val next = if (front == 0) 1 else 0
        val s = slots[next]
        // alpha 0.01 (not 0): Android skips drawing a fully transparent TextureView, and then the decoder would stall waiting for it
        s.view.alpha = 0.01f
        s.view.bringToFront()
        s.player.setMediaItem(MediaItem.fromUri(uri(req.res)))
        s.player.prepare()
        s.player.seekTo(0)
        s.player.playWhenReady = !paused
        awaitFirstFrame(s.player)
        if (released) return
        // the new clip lies on top and fades IN over the old one (no dip to black)
        val old = if (front >= 0) slots[front] else null
        try {
            fade.snapTo(0.01f)
            fade.animateTo(1f, tween(ms, easing = LinearEasing)) { s.view.alpha = value }
        } finally {
            // Runs on success AND when a newer request cancels this one half way: always leave a clean state
            // (new clip fully shown, old clip hidden and paused) so the next request starts from a known picture.
            s.view.alpha = 1f
            if (old != null) { old.view.alpha = 0f; old.player.pause() }
            front = next
            hasShown = true
        }
    }

    private suspend fun awaitFirstFrame(p: ExoPlayer) {
        val done = CompletableDeferred<Unit>()
        val l = object : Player.Listener {
            override fun onRenderedFirstFrame() { done.complete(Unit) }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) { done.complete(Unit) } // never hang on an error
        }
        p.addListener(l)
        try { withTimeoutOrNull(1500) { done.await() } } finally { p.removeListener(l) }
    }

    fun pause() { paused = true; slots.forEach { it.player.pause() } }
    fun resume() {
        paused = false
        if (front >= 0) slots[front].player.play()
    }

    fun release() {
        released = true
        slots.forEach { try { it.player.release() } catch (e: Exception) { } }
        root.removeAllViews()
    }
}
