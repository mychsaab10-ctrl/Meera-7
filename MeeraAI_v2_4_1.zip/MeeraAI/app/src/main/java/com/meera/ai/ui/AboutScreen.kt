package com.meera.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AboutScreen(onBack: () -> Unit) {
    SubScreen("About Meera AI", onBack) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Avatar(110.dp)
            Text("Meera AI  v2.4.0", fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
            Text("Owner and developer: ADIL", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
            Text("Meera is an AI companion, not a human. She can make mistakes - double-check important things yourself.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        SectionTitle("New in 2.4")
        Text(
            "💎 New glassmorphism design everywhere.\n🎬 Home: full-screen sci-fi video with soft mix at loop start/end.\n🧑 Call: Meera fills the whole screen as an animated avatar; her expression changes smoothly (normal, blink, talking, sad, excited, thinking, happy).\n🔒 Location is now private (see below).",
            fontSize = 13.sp
        )
        SectionTitle("2.3")
        Text(
            "🔒 Location: Location Gemini ko kabhi nahi bheji jati; sirf phone par, aapke \"yes\" ke baad padhi jati hai. Say \"where am I?\" / \"main kahan hoon\" - Meera asks \"Can I check your location now? (yes / no)\" and shows the answer only on the screen and in the phone's own voice. Maps (navigate / nearby) use only the place name; Google Maps finds you itself.\n" +
                "🧠 Better memory: Meera now remembers lasting things you tell her automatically (like ChatGPT) and keeps your recent chat. Everything is visible, editable and deletable in Memory; Auto memory can be turned off.\n" +
                "👤 Meera always knows her owner and developer is ADIL. It is built in and cannot be changed from chat, calls or Settings.\n" +
                "📱 More phone control: navigation, nearby search, flashlight, volume, media keys, phone status, email and share drafts, Play Store search, more settings pages, and (with screen control on) swipe, type, notifications, quick settings, screenshot, lock screen.\n" +
                "🌐 English app text. Meera speaks only Roman Urdu and English.",
            fontSize = 13.sp
        )
        SectionTitle("2.2: Meera Aura")
        Text(
            "✨ A glowing border around the screen edges while Meera listens, thinks and speaks; it pulses with her voice.\n" +
                "✨ Modes: Off / App only / Whole phone (needs \"Display over other apps\" or Meera turned on in Accessibility).",
            fontSize = 13.sp
        )
        SectionTitle("2.1: Meera Eyes")
        Text(
            "👀 Say \"Meera open your eyes\" / \"aankhein kholo\" / \"camera on\" (close: \"close your eyes\" / \"aankhein band karo\" / \"camera off\") in chat or a call.\n" +
                "👀 The camera runs only on your command. Frames go only to Gemini while the eyes are ON; nothing is saved or recorded.\n" +
                "👀 HUD brackets and labels on objects. A person is only labelled \"HUMAN\".\n" +
                "👀 Ask \"what is this?\" and Meera explains by voice and in a text card.\n" +
                "👀 Auto-close after 5 minutes (changeable), in the background, or when the phone is hot or the battery is low.",
            fontSize = 13.sp
        )
        SectionTitle("Implemented")
        Text(
            "✅ Gemini chat (the model list refreshes from Google)\n" +
                "✅ Web search (Google grounding) in Chat\n" +
                "✅ Calling: Gemini Live API + fallback (recognizer + TTS)\n" +
                "✅ Intents: apps, YouTube, music, browser, maps, camera, settings, alarm, timer, calendar, dial, SMS, email\n" +
                "✅ Accessibility: read screen, tap, scroll, swipe, type, back/home (opt-in)\n" +
                "✅ Notification reading (opt-in) + summary\n" +
                "✅ Coding mode with copy / save file\n" +
                "✅ Memory (auto + manual, view/edit/delete/clear), summaries\n" +
                "✅ OCR, image Q&A, PDF summary, translate, study, writing, planner, voice notes\n" +
                "✅ WhatsApp / SMS by number or contact name (confirmation first, optional auto-Send)\n" +
                "✅ Confirmations by talking (yes / no, or haan / nahi), no popups\n" +
                "✅ Avatar with 8 expressions\n" +
                "✅ Quick-access notification",
            fontSize = 13.sp
        )
        SectionTitle("Not implemented (honest list)")
        Text(
            "❌ Recognizing Adil by voice (planned)\n" +
                "❌ Custom wake word (needs an always-on mic and battery)\n" +
                "❌ Floating bubble\n" +
                "❌ Screen capture (MediaProjection)\n" +
                "❌ Auto-calling (the dialer opens, you press Call)\n" +
                "❌ Silent Wi-Fi/Bluetooth/airplane toggles, installing apps, bypassing the lock screen: Android does not allow these\n" +
                "⚠ Live API protocol and model names change often - if Live fails, refresh the model list in Settings; the fallback starts by itself.",
            fontSize = 13.sp
        )
    }
}
