package com.meera.ai.voice

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import com.meera.ai.Meera
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicLong

/**
 * Live microphone capture: 16 kHz mono PCM16, 100 ms chunks.
 * Some phones open the mic fine but deliver only zeros for a given source/mode. If ~4 s of pure silence arrives,
 * the next "stage" is tried automatically: 0 = VOICE_COMMUNICATION (+echo/noise filters), 1 = MIC (no filters),
 * 2 = VOICE_RECOGNITION (the caller is told so it can leave call-audio mode). onProblem is called only when all stages are silent.
 */
class AudioCapture(
    private val onProblem: (String) -> Unit = {},
    private val onStage: (Int) -> Unit = {},
    private val onChunk: (ByteArray) -> Unit
) {
    @Volatile var muted = false
    @Volatile private var rec: AudioRecord? = null
    private var job: Job? = null
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null
    private val lock = Any()

    private val sources = intArrayOf(
        MediaRecorder.AudioSource.VOICE_COMMUNICATION,
        MediaRecorder.AudioSource.MIC,
        MediaRecorder.AudioSource.VOICE_RECOGNITION
    )

    @SuppressLint("MissingPermission") // permission is checked by CallController before start()
    private fun open(stage: Int): AudioRecord? {
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = try {
            AudioRecord(sources[stage], 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 6400) * 2)
        } catch (e: Exception) { return null }
        if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); return null }
        try { r.startRecording() } catch (e: Exception) { r.release(); return null }
        if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) { r.release(); return null }
        if (stage == 0) {
            if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(r.audioSessionId)?.also { it.setEnabled(true) }
            if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(r.audioSessionId)?.also { it.setEnabled(true) }
        }
        return r
    }

    private fun closeRec() {
        synchronized(lock) {
            rec?.let {
                try { it.stop() } catch (e: Exception) { }
                try { it.release() } catch (e: Exception) { }
            }
            rec = null
            try { aec?.release() } catch (e: Exception) { }
            try { ns?.release() } catch (e: Exception) { }
            aec = null; ns = null
        }
    }

    /** Opens the first stage >= from that works. Returns the stage number or -1. */
    private fun openFrom(from: Int): Int {
        for (st in from until sources.size) {
            val r = open(st)
            if (r != null) { synchronized(lock) { rec = r }; return st }
        }
        return -1
    }

    fun start(scope: CoroutineScope) {
        if (job != null) return // never run two mic sessions
        var stage = openFrom(0)
        if (stage < 0) throw IllegalStateException("Microphone could not start. Check Android microphone permission, the mic privacy switch, and that no other app is using the mic.")
        job = scope.launch(Dispatchers.IO) {
            val buf = ByteArray(3200)
            var silentChunks = 0
            while (isActive) {
                val r = synchronized(lock) { rec } ?: break
                val n = r.read(buf, 0, buf.size)
                if (n < 0) { onProblem("Microphone stopped (read error $n)."); break }
                if (n == 0) { delay(20); continue }
                var peak = 0
                var i = 0
                while (i + 1 < n) {
                    val v = (buf[i].toInt() and 0xFF) or (buf[i + 1].toInt() shl 8)
                    val a = if (v < 0) -v else v
                    if (a > peak) peak = a
                    i += 2
                }
                if (peak == 0) {
                    silentChunks++
                    if (silentChunks >= 40) { // ~4 s of pure silence: try the next way of opening the mic
                        silentChunks = 0
                        closeRec()
                        val next = openFrom(stage + 1)
                        if (next < 0) {
                            onProblem("Microphone gives only silence (tried 3 ways). Allow Microphone for Meera in Android Settings, turn off the mic privacy switch, and test the phone's Voice Recorder app.")
                            break
                        }
                        stage = next
                        onStage(stage)
                        continue
                    }
                } else silentChunks = 0
                if (!muted) onChunk(buf.copyOf(n))
            }
        }
    }

    fun stop() {
        job?.cancel(); job = null
        closeRec()
    }
}

/** Streaming PCM16 player at 24 kHz (Gemini Live output rate). */
class AudioPlayer {
    private val rate = 24000
    private val track: AudioTrack
    private val queue = Channel<ByteArray>(Channel.UNLIMITED)
    private val framesWritten = AtomicLong(0)
    private var writer: Job? = null
    @Volatile private var epoch = 0

    init {
        val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(maxOf(min, 24000))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track.play()
    }

    fun start(scope: CoroutineScope) {
        if (writer != null) return
        writer = scope.launch(Dispatchers.IO) {
            for (chunk in queue) {
                val myEpoch = epoch
                var off = 0
                while (off < chunk.size && isActive && myEpoch == epoch) {
                    val n = track.write(chunk, off, minOf(4800, chunk.size - off))
                    if (n <= 0) break
                    Meera.aura.feedPcm(chunk, off, n) // real loudness of what is playing -> Aura border pulse
                    off += n
                    framesWritten.addAndGet((n / 2).toLong())
                }
            }
        }
    }

    fun enqueue(pcm: ByteArray) {
        queue.trySend(pcm)
    }

    /** Barge-in: drop everything queued and stop sound immediately. */
    fun flush() {
        epoch++
        while (queue.tryReceive().isSuccess) { /* drain */ }
        try {
            track.pause(); track.flush(); track.play()
        } catch (e: Exception) { }
        framesWritten.set(0)
    }

    /** Suspends until what was queued has really been played. */
    suspend fun awaitDrained() {
        var guard = 0
        while (guard < 600) { // max 30 s
            val head = try { track.playbackHeadPosition.toLong() } catch (e: Exception) { return }
            if (head >= framesWritten.get() && queue.isEmpty) return
            delay(50); guard++
        }
    }

    fun release() {
        writer?.cancel(); writer = null
        queue.close()
        try { track.pause(); track.flush(); track.release() } catch (e: Exception) { }
    }
}
